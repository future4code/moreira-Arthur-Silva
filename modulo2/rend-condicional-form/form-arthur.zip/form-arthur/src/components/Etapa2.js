import React from 'react'


class Etapa2 extends React.Component{
  render(){
    return (
      <div>
          <h2>Etapa 2 - Informações do ensino superior</h2>
          <div>
              <p>5. Qual curso?</p>
              <input type="text"/>
          </div>
          <div>
              <p>6. Qual a unidade de ensino?</p>
              <input type="text"/>
          </div>
          
      </div>    
    );
  }  
}

export default Etapa2;
