import React from 'react'


class Etapa1 extends React.Component{
  render(){
    return (
      <div>
        <h1>Etapa 1 - Dados Gerais</h1>

        <div>
          <p>1. Qual o seu nome?</p>
          <input type="text"/>
        </div>
        <div>
          <p>2. Qual sua idade?</p>
          <input type="text"/>
        </div>
        <div>
          <p>3. Qual seu email?</p>
          <input type="text"/>
        </div>
        <div>
          <p>Qual a sua escolaridade?</p>
          <select>
            <option>Ensino médio incompleto</option>
            <option>Ensino médio completo</option>
            <option>Ensino superior incompleto</option>
            <option>Ensino superior completo</option>
          </select>
        </div>
        
      </div>
    );
  }  
}

export default Etapa1;
